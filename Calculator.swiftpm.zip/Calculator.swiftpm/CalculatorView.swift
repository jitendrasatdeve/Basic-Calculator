import SwiftUI

private enum CalcOp: String {
    case add = "+", sub = "−", mul = "×", div = "÷"
}

struct CalculatorView: View {
    @State private var display: String = "0"
    @State private var accumulator: Double? = nil
    @State private var pendingOp: CalcOp? = nil
    @State private var isEnteringFraction: Bool = false
    @State private var lastButtonWasEquals: Bool = false

    private let buttons: [[String]] = [
        ["AC", "+/−", "%", "÷"],
        ["7", "8", "9", "×"],
        ["4", "5", "6", "−"],
        ["1", "2", "3", "+"],
        ["0", ".", "="]
    ]

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 12) {
                Spacer()
                HStack {
                    Spacer()
                    Text(display)
                        .foregroundStyle(.white)
                        .font(.system(size: 72, weight: .light, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.3)
                        .accessibilityIdentifier("calculatorDisplay")
                }
                .padding(.horizontal, 24)

                Grid(horizontalSpacing: 12, verticalSpacing: 12) {
                    GridRow {
                        CalculatorButton(title: "AC") { handleTap("AC") }
                        CalculatorButton(title: "+/−") { handleTap("+/−") }
                        CalculatorButton(title: "%") { handleTap("%") }
                        CalculatorButton(title: "÷") { handleTap("÷") }
                    }
                    GridRow {
                        CalculatorButton(title: "7") { handleTap("7") }
                        CalculatorButton(title: "8") { handleTap("8") }
                        CalculatorButton(title: "9") { handleTap("9") }
                        CalculatorButton(title: "×") { handleTap("×") }
                    }
                    GridRow {
                        CalculatorButton(title: "4") { handleTap("4") }
                        CalculatorButton(title: "5") { handleTap("5") }
                        CalculatorButton(title: "6") { handleTap("6") }
                        CalculatorButton(title: "−") { handleTap("−") }
                    }
                    GridRow {
                        CalculatorButton(title: "1") { handleTap("1") }
                        CalculatorButton(title: "2") { handleTap("2") }
                        CalculatorButton(title: "3") { handleTap("3") }
                        CalculatorButton(title: "+") { handleTap("+") }
                    }
                    GridRow {
                        CalculatorButton(title: "0", isWide: true) { handleTap("0") }
                            .gridCellColumns(2)
                        CalculatorButton(title: ".") { handleTap(".") }
                        CalculatorButton(title: "=") { handleTap("=") }
                    }
                }
                .padding(.bottom, 12)
            }
            .padding(.bottom)
        }
    }

    private func handleTap(_ title: String) {
        switch title {
        case "0"..."9":
            enterDigit(title)
        case ".":
            enterDot()
        case "+":
            pendingOperator(.add)
        case "−":
            pendingOperator(.sub)
        case "×":
            pendingOperator(.mul)
        case "÷":
            pendingOperator(.div)
        case "=":
            equals()
        case "AC":
            clearAll()
        case "+/−":
            toggleSign()
        case "%":
            percent()
        default:
            break
        }
    }

    private func enterDigit(_ d: String) {
        if lastButtonWasEquals && pendingOp == nil {
            // Start new entry after equals
            accumulator = nil
            display = "0"
        }
        lastButtonWasEquals = false

        if display == "0" || (pendingOp != nil && accumulator != nil && !isEnteringFraction && display == formatted(accumulator!)) {
            display = d
        } else {
            display.append(d)
        }
    }

    private func enterDot() {
        lastButtonWasEquals = false
        if !display.contains(".") {
            display.append(".")
            isEnteringFraction = true
        }
    }

    private func pendingOperator(_ op: CalcOp) {
        lastButtonWasEquals = false
        let current = Double(display) ?? 0
        if let existing = accumulator, let pending = pendingOp {
            let result = apply(op: pending, lhs: existing, rhs: current)
            accumulator = result
            display = formatted(result)
        } else {
            accumulator = current
        }
        pendingOp = op
        isEnteringFraction = false
    }

    private func equals() {
        let current = Double(display) ?? 0
        if let existing = accumulator, let pending = pendingOp {
            let result = apply(op: pending, lhs: existing, rhs: current)
            display = formatted(result)
            accumulator = nil
            pendingOp = nil
        }
        lastButtonWasEquals = true
        isEnteringFraction = false
    }

    private func clearAll() {
        display = "0"
        accumulator = nil
        pendingOp = nil
        isEnteringFraction = false
        lastButtonWasEquals = false
    }

    private func toggleSign() {
        if display == "0" { return }
        if display.hasPrefix("-") {
            display.removeFirst()
        } else {
            display = "-" + display
        }
    }

    private func percent() {
        let value = (Double(display) ?? 0) / 100.0
        display = formatted(value)
    }

    private func apply(op: CalcOp, lhs: Double, rhs: Double) -> Double {
        switch op {
        case .add: return lhs + rhs
        case .sub: return lhs - rhs
        case .mul: return lhs * rhs
        case .div: return rhs == 0 ? lhs : lhs / rhs
        }
    }

    private func formatted(_ value: Double) -> String {
        if value.isNaN || value.isInfinite { return "Error" }
        let formatter = NumberFormatter()
        formatter.maximumFractionDigits = 10
        formatter.minimumFractionDigits = 0
        formatter.usesGroupingSeparator = false
        return formatter.string(from: NSNumber(value: value)) ?? String(value)
    }
}

private struct CalculatorButton: View {
    let title: String
    var isWide: Bool = false
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 32, weight: .semibold, design: .rounded))
                .frame(maxWidth: .infinity, minHeight: 72, maxHeight: 72)
                .foregroundStyle(.white)
                .background(backgroundColor)
                .clipShape(RoundedRectangle(cornerRadius: 36, style: .continuous))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("calculator_" + title)
    }

    private var backgroundColor: Color {
        switch title {
        case "÷", "×", "−", "+", "=":
            return Color.orange
        case "AC", "+/−", "%":
            return Color(white: 0.35)
        default:
            return Color(white: 0.2)
        }
    }
}

#Preview {
    CalculatorView()
}
